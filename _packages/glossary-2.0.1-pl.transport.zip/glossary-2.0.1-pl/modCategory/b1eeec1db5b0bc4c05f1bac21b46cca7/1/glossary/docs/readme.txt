------------------------
Extra: Glossary
------------------------
Version 1.1

Display and manage a glossary of terms on your site.

Full source & documentation available at
https://github.com/alanpich/modx-glossary
