<?php
/**
 * Glossary Base Classfile
 *
 * Copyright 2012-2016 by Alan Pich <alan.pich@gmail.com>
 *
 * @package glossary
 * @subpackage classfile
 */

/**
 * class GlossaryBase
 */
class GlossaryBase
{
    /**
     * A reference to the modX instance
     * @var modX $modx
     */
    public $modx;

    /**
     * The namespace
     * @var string $namespace
     */
    public $namespace = 'glossary';

    /**
     * The version
     * @var string $version
     */
    public $version = '1.2.0';

    /**
     * The class config
     * @var array $config
     */
    public $config = array();

    /**
     * GlossaryBase constructor
     *
     * @param modX $modx A reference to the modX instance.
     * @param array $config An config array. Optional.
     */
    function __construct(modX &$modx, $config = array())
    {
        $this->modx =& $modx;

        $corePath = $this->getOption('core_path', $config, $this->modx->getOption('core_path') . 'components/' . $this->namespace . '/');
        $assetsPath = $this->getOption('assets_path', $config, $this->modx->getOption('assets_path') . 'components/' . $this->namespace . '/');
        $assetsUrl = $this->getOption('assets_url', $config, $this->modx->getOption('assets_url') . 'components/' . $this->namespace . '/');

        // Load some default paths for easier management
        $this->config = array_merge(array(
            'namespace' => $this->namespace,
            'version' => $this->version,
            'assetsPath' => $assetsPath,
            'assetsUrl' => $assetsUrl,
            'cssUrl' => $assetsUrl . 'css/',
            'jsUrl' => $assetsUrl . 'js/',
            'imagesUrl' => $assetsUrl . 'images/',
            'connectorUrl' => $assetsUrl . 'connector.php',
            'corePath' => $corePath,
            'modelPath' => $corePath . 'model/',
            'vendorPath' => $corePath . 'vendor/',
            'chunksPath' => $corePath . 'elements/chunks/',
            'pagesPath' => $corePath . 'elements/pages/',
            'snippetsPath' => $corePath . 'elements/snippets/',
            'pluginsPath' => $corePath . 'elements/plugins/',
            'controllersPath' => $corePath . 'controllers/',
            'processorsPath' => $corePath . 'processors/',
            'templatesPath' => $corePath . 'templates/',
        ), $config);

        // set default options
        $this->config = array_merge($this->config, array(
            'glossaryStart' => $this->getOption('glossaryStart', $config, '<!-- GlossaryStart -->'),
            'glossaryEnd' => $this->getOption('glossaryEnd', $config, '<!-- GlossaryEnd -->'),
        ));

        $modx->getService('lexicon', 'modLexicon');
        $this->modx->lexicon->load($this->namespace . ':default');

        $this->modx->addPackage('glossary', $this->config['modelPath']);
    }

    /**
     * Get a local configuration option or a namespaced system setting by key.
     *
     * @param string $key The option key to search for.
     * @param array $options An array of options that override local options.
     * @param mixed $default The default value returned if the option is not found locally or as a
     * namespaced system setting; by default this value is null.
     * @return mixed The option value or the default value specified.
     */
    public function getOption($key, $options = array(), $default = null)
    {
        $option = $default;
        if (!empty($key) && is_string($key)) {
            if ($options != null && array_key_exists($key, $options)) {
                $option = $options[$key];
            } elseif (array_key_exists($key, $this->config)) {
                $option = $this->config[$key];
            } elseif (array_key_exists("{$this->namespace}.{$key}", $this->modx->config)) {
                $option = $this->modx->getOption("{$this->namespace}.{$key}");
            }
        }
        return $option;
    }

    public function getGroupedTerms()
    {
        /** @var Term[] $terms */
        $terms = $this->modx->getCollection('Term');
        $letters = array(
            'A' => array(), 'B' => array(), 'C' => array(),
            'D' => array(), 'E' => array(), 'F' => array(),
            'G' => array(), 'H' => array(), 'I' => array(),
            'J' => array(), 'K' => array(), 'L' => array(),
            'M' => array(), 'N' => array(), 'O' => array(),
            'P' => array(), 'Q' => array(), 'R' => array(),
            'S' => array(), 'T' => array(), 'U' => array(),
            'V' => array(), 'W' => array(), 'X' => array(),
            'Y' => array(), 'Z' => array(), '0' => array(),
            '1' => array(), '2' => array(), '3' => array(),
            '4' => array(), '5' => array(), '6' => array(),
            '7' => array(), '8' => array(), '9' => array()
        );
        $tmp = $this->modx->newObject('modResource');
        foreach ($terms as $termObj) {
            $term = $termObj->toArray();
            $cleanTerm = $tmp->cleanAlias($term['term']);
            $firstLetter = strtoupper(substr($cleanTerm, 0, 1));
            $letters[$firstLetter][] = $term;
        };
        return $letters;
    }

    public function getTerms()
    {
        /** @var Term[] $terms */
        $terms = $this->modx->getCollection('Term');
        $retArray = array();
        foreach ($terms as $term) {
            $retArray[] = $term->toArray();
        };
        return $retArray;
    }

    public function linkifyContent($content, $targetResId, $chunkName)
    {
        // Generate URL to target page
        $target = $this->modx->makeUrl($targetResId);

        // Enable section markers
        $enableSections = $this->getOption('sections', null, false);
        if ($enableSections) {
            $splitEx = '#((?:' . $this->getOption('glossaryStart') . ').*?(?:' . $this->getOption('glossaryEnd') . '))#isu';
            $sections = preg_split($splitEx, $content, null, PREG_SPLIT_DELIM_CAPTURE);
        } else {
            $sections = array($content);
        }

        // Parse and create links for each term
        $terms = $this->getTerms();
        foreach ($terms as $term) {
            $chunk = '';
            if ($this->getOption('fullwords', null, true)) {
                foreach ($sections as &$section) {
                    if (($enableSections && substr($section, 0, strlen($this->getOption('glossaryStart'))) == $this->getOption('glossaryStart') && preg_match('/\b' . $term['term'] . '\b/u', $section)) ||
                        (!$enableSections && preg_match('/\b' . $term['term'] . '\b/u', $section))
                    ) {
                        if (!$chunk) {
                            $chunk = $this->modx->getChunk($chunkName, array(
                                'link' => $target . '#' . strtolower(str_replace(' ', '-', $term['term'])),
                                'term' => $term['term'],
                                'explanation' => htmlspecialchars($term['explanation'], ENT_QUOTES, $this->modx->getOption('modx_charset'))
                            ));
                            // Escape the substitutions
                            $chunk = preg_replace('/(\$|\\\\)(?=\d|\{|g\<|x|t|r|n|f)/', '\\\\\1', $chunk);
                        }
                        $section = preg_replace('/\b' . $term['term'] . '\b/u', $chunk, $section);
                    }
                }
            } else {
                foreach ($sections as &$section) {
                    if (($enableSections && substr($section, 0, strlen($this->getOption('glossaryStart'))) == $this->getOption('glossaryStart') && strpos($content, $term['term']) !== false) ||
                        (!$enableSections && strpos($content, $term['term']) !== false)
                    ) {
                        if (!$chunk) {
                            $chunk = $this->modx->getChunk($chunkName, array(
                                'link' => $target . '#' . strtolower(str_replace(' ', '-', $term['term'])),
                                'term' => $term['term'],
                                'explanation' => htmlspecialchars($term['explanation'], ENT_QUOTES, $this->modx->getOption('modx_charset'))
                            ));
                        }
                        $section = str_replace($term['term'], $chunk, $section);
                    }
                }
            }
        };
        $content = implode('', $sections);
        // Remove remaining section markers
        $content = ($enableSections) ? str_replace(array($this->getOption('glossaryStart'), $this->getOption('glossaryEnd')), '', $content) : $content;
        return $content;
    }
}
