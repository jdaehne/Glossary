## Contributors

The Glossary project was started in 2012 by [Alan Pich](https://github.com/alanpich).

Many thanks to everyone else who has contributed to this project:

* [@vundicind](https://github.com/vundicind)
* [@Jako](https://github.com/Jako)
