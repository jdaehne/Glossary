<?php
$_lang['prop_glossary.outerTpl_desc'] = 'Template chunk for glossary outer wrapper';
$_lang['prop_glossary.groupTpl_desc'] = 'Template chunk for glossary item groups';
$_lang['prop_glossary.termTpl_desc'] = 'Template chunk for glossary term items';
$_lang['prop_glossary.showNav_desc'] = 'Shows a quick-nav bar at the top of the glossary';
$_lang['prop_glossary.navOuterTpl_desc'] = 'Template chunk for outer nav-bar wrapper';
$_lang['prop_glossary.navItemTpl_desc'] = 'Template chunk for each item in the nav-bar';
