<?php
$_lang['prop_glossary.outerTpl_desc'] = 'Template Chunk für das Glossar';
$_lang['prop_glossary.groupTpl_desc'] = 'Template Chunk für eine Glossar-Begriffsgruppe ';
$_lang['prop_glossary.termTpl_desc'] = 'Template Chunk für einen Glossar-Begriff';
$_lang['prop_glossary.showNav_desc'] = 'Schnell-Navigationsleiste am oberen Rand des Glossars anzeigen';
$_lang['prop_glossary.navOuterTpl_desc'] = 'Template Chunk für die Schnell-Navigationsleiste';
$_lang['prop_glossary.navItemTpl_desc'] = 'Template Chunk für ein Element in der Schnell-Navigationsleiste';
