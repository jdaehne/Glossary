Glossary
========

Authors: Alan Pich <alan.pich@gmail.com>
         Thomas Jakobi <thomas.jakobi@partout.info>
License: GNU GPLv2

Display and manage a glossary of terms on your site.

Usage
-----
Install via package manager

Documentation
-------------
http://jako.github.io/Glossary/

GitHub Repository
-----------------
https://github.com/Jako/Glossary